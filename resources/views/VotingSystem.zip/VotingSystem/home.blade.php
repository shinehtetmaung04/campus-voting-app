<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Home Page</title>

  <!-- Google Icons -->
  <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet">

  <!-- External CSS -->
  <link rel="stylesheet" href="{{ asset('css/Home.css') }}">
</head>

<body>

<header class="top-bar">
  <div class="menu-icon">
    <img src="Images/logo.png" alt="Logo">
    <div class="logo">University of Computer Studies(Thaton)</div>

    <div class="user-area mobile-user">
      <span class="material-symbols-outlined">event_available</span>
    </div>

    <div class="user-area desktop-user">
      <span class="material-symbols-outlined">event_available</span>
    </div>
  </div>

  <nav class="sub-nav-links" id="navLinks">
    <a href="#" class="active">Home</a>
    <span>•</span>
    <a href="king_selection">King</a>
    <span>•</span>
    <a href="queen_selection">Queen</a>
  </nav>
</header>

<section class="ranking-section">
  <div class="ranking-container">
    <div class="contest-card">

      <div class="slider">
        <img src="./Images/1.jpg" data-left="Mg Aung Aung" data-right="Ma Si Si" data-rank="1">
        <img src="./Images/2.jpg" data-left="Mg Kyaw Kyaw" data-right="Ma Hnin Hnin" data-rank="2">
        <img src="./Images/3.jpg" data-left="Mg Tun Tun" data-right="Ma Su Su" data-rank="3">
        <div class="slider-dots"></div>
      </div>

      <div class="card-body">
        <div class="name-pair">
          <h3 id="leftName"></h3>
          <h3 id="rightName"></h3>
        </div>
        <div class="rank-badge rank-badge-floating" id="rankBadge"></div>

      </div>

    </div>
  </div>
</section>
<section class="ranking-section">
  <div class="ranking-container">
    <div class="contest-card">

      <div class="slider">
        <img src="./Images/1.jpg" data-left="Mg Aung Aung" data-right="Ma Si Si" data-rank="1">
        <img src="./Images/2.jpg" data-left="Mg Kyaw Kyaw" data-right="Ma Hnin Hnin" data-rank="2">
        <img src="./Images/3.jpg" data-left="Mg Tun Tun" data-right="Ma Su Su" data-rank="3">
        <div class="slider-dots"></div>
      </div>

      <div class="card-body">
        <div class="name-pair">
          <h3 id="leftName"></h3>
          <h3 id="rightName"></h3>
        </div>
        <div class="rank-badge" id="rankBadge"></div>
      </div>

    </div>
  </div>
</section>

<script>
  
document.querySelectorAll(".slider").forEach(slider => {
  const slides = slider.querySelectorAll("img");
  const dotsContainer = slider.querySelector(".slider-dots");

  const leftName = document.getElementById("leftName");
  const rightName = document.getElementById("rightName");
  const rankBadge = document.getElementById("rankBadge");

  let currentIndex = 0;
  let startX = 0;
  let currentX = 0;
  let isDragging = false;

  slides.forEach((_, i) => {
    const dot = document.createElement("span");
    if (i === 0) dot.classList.add("active");
    dot.addEventListener("click", () => {
      currentIndex = i;
      updateSlides();
      updateInfo();
    });
    dotsContainer.appendChild(dot);
  });

  const dots = dotsContainer.querySelectorAll("span");

  slides.forEach((img, i) => {
    img.style.transform = `translateX(${i * 100}%)`;
  });

  function updateSlides(offset = 0) {
    slides.forEach((img, i) => {
      img.style.transform = `translateX(${(i - currentIndex) * 100 + offset}%)`;
    });
    dots.forEach((dot, i) => dot.classList.toggle("active", i === currentIndex));
  }

  function updateInfo() {
    const active = slides[currentIndex];
    leftName.textContent = active.dataset.left;
    rightName.textContent = active.dataset.right;
    rankBadge.textContent = active.dataset.rank;
  }

  function startDrag(x) {
    startX = x;
    isDragging = true;
  }

  function onDrag(x) {
    if (!isDragging) return;
    currentX = x - startX;
    const percent = (currentX / slider.offsetWidth) * 100;
    updateSlides(percent);
  }

  function endDrag() {
    if (!isDragging) return;
    isDragging = false;

    const threshold = slider.offsetWidth * 0.25;
    if (currentX < -threshold && currentIndex < slides.length - 1) currentIndex++;
    else if (currentX > threshold && currentIndex > 0) currentIndex--;

    updateSlides();
    updateInfo();
    currentX = 0;
  }

  updateInfo();

  slider.addEventListener("mousedown", e => startDrag(e.clientX));
  window.addEventListener("mousemove", e => onDrag(e.clientX));
  window.addEventListener("mouseup", endDrag);

  slider.addEventListener("touchstart", e => startDrag(e.touches[0].clientX));
  slider.addEventListener("touchmove", e => onDrag(e.touches[0].clientX));
  slider.addEventListener("touchend", endDrag);
});

// Active menu link
</script>

</body>
</html>
