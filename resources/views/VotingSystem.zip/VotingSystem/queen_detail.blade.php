<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Queen Selection Details Page</title>

  <!-- Google Icons -->
  <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet" />

  <!-- External CSS -->
  <link rel="stylesheet" href="{{ asset('css/king_selection.css') }}" />
  <link rel="stylesheet" href="{{ asset('css/king_detail.css') }}" />
</head>
<body>
  <header class="top-bar">
    <div class="menu-icon">
       <img src="{{ asset('Images/logo.png') }}" alt="Logo" />
      <div class="logo">University of Computer Studies(Thaton)</div>

      <div class="user-area mobile-user">
        <span class="material-symbols-outlined">event_available</span>
      </div>

      <div class="user-area desktop-user">
        <span class="material-symbols-outlined">event_available</span>
      </div>
    </div>

    <nav class="sub-nav-links" id="navLinks">
      <a href="{{ asset('home') }}">Home</a>
      <span>•</span>
      <a href="{{ asset('king_selection') }}">King</a>
      <span>•</span>
      <a href="#" class="active">Queen</a>
    </nav>
  </header>
@php
    $loginCode = session('login_code');
    $currentUser = \App\Models\User::where('login_code', $loginCode)->first();
@endphp
  <section class="ranking-section">
    <div class="ranking-container">
      <!-- Card 1 -->
      <div class="contest-card second">
        <div class="slider">
          <!-- Example static images (can be dynamic later) -->
          <a href=""><img src="{{ asset('Images/1.jpg') }}" alt="Contestant" /></a>
          <a href=""><img src="{{ asset('Images/2.jpg') }}" alt="Contestant" /></a>
          <a href=""><img src="{{ asset('Images/3.jpg') }}" alt="Contestant" /></a>
          <div class="slider-dots"></div>
        </div>

        <div class="card-body">
          <div class="name-pair">
            <h3 class="left-name">{{ $queen->name }}</h3>
            <div class="rank-badge">{{ $queen->number }}</div>
          </div>

          <table>
            <tr>
              <td class="pfLeft">Birthday</td>
              <td>:</td>
              <td class="pfRight">
                {{ \Carbon\Carbon::parse($queen->birthday)->format('F d Y') }}
              </td>
            </tr>
            <tr>
              <td class="pfLeft">Zodiac</td>
              <td>:</td>
              <td class="pfRight">{{ $queen->zodiac }}</td>
            </tr>
            <tr>
              <td class="pfLeft">Hobby</td>
              <td>:</td>
              <td class="pfRight">{{ $queen->hobby }}</td>
            </tr>
            <tr>
              <td class="pfLeft">Address</td>
              <td>:</td>
              <td class="pfRight">{{ $queen->address }}</td>
            </tr>
          </table>

          <!-- Vote + Back arrow -->
          <div class="votebutton-container">
            <button class="back-arrow-modern"
              onclick="window.location.href='/queen_selection'">
              &#8592;
            </button>

                <form method="POST" action="{{ route('vote.queen', ['id' => $queen->sel_id]) }}">
    @csrf
    <button type="submit" class="vote1"
        @if($currentUser && $currentUser->qflag == 0)
            disabled style="cursor: not-allowed; opacity: 0.2;"
        @endif>
        Vote
    </button>
</form>
          </div>

        </div>
      </div>
    </div>
  </section>

  <script>
    document.querySelectorAll('.slider').forEach((slider) => {
      const slides = slider.querySelectorAll('img');
      let currentIndex = 0;
      let startX = 0;
      let currentX = 0;
      let isDragging = false;

      const dotsContainer = slider.querySelector('.slider-dots');
      slides.forEach((_, i) => {
        const dot = document.createElement('span');
        if (i === 0) dot.classList.add('active');
        dot.addEventListener('click', () => {
          currentIndex = i;
          updateSlides();
        });
        dotsContainer.appendChild(dot);
      });
      const dots = dotsContainer.querySelectorAll('span');

      slides.forEach((img, i) => (img.style.transform = `translateX(${i * 100}%)`));

      function updateSlides(offset = 0) {
        slides.forEach((img, i) => {
          img.style.transform = `translateX(${(i - currentIndex) * 100 + offset}%)`;
        });
        dots.forEach((dot, i) => dot.classList.toggle('active', i === currentIndex));
      }

      function startDrag(x) {
        startX = x;
        isDragging = true;
      }
      function onDrag(x) {
        if (!isDragging) return;
        currentX = x - startX;
        const percent = (currentX / slider.offsetWidth) * 100;
        updateSlides(percent);
      }
      function endDrag() {
        if (!isDragging) return;
        isDragging = false;
        const threshold = slider.offsetWidth * 0.25;
        if (currentX < -threshold && currentIndex < slides.length - 1) currentIndex++;
        else if (currentX > threshold && currentIndex > 0) currentIndex--;
        updateSlides();
        currentX = 0;
      }

      slider.addEventListener('mousedown', (e) => startDrag(e.clientX));
      window.addEventListener('mousemove', (e) => onDrag(e.clientX));
      window.addEventListener('mouseup', endDrag);

      slider.addEventListener('touchstart', (e) => startDrag(e.touches[0].clientX));
      slider.addEventListener('touchmove', (e) => onDrag(e.touches[0].clientX));
      slider.addEventListener('touchend', endDrag);
    });

    // Active menu link
    const currentURL = window.location.href;
    document.querySelectorAll('.sub-nav-links a').forEach((link) => {
      if (currentURL.includes(link.getAttribute('href'))) {
        link.classList.add('active');
      }
    });
  </script>
</body>
</html>
