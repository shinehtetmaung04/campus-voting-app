<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>King Selection Page</title>

  <!-- Google Icons -->
  <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet">

  <!-- External CSS -->
  <link rel="stylesheet" href="{{ asset('css/king_selection.css') }}">
</head>
<body>

<header class="top-bar">
  <div class="menu-icon">
    <img src="Images/logo.png" alt="Logo">
    <div class="logo">University of Computer Studies(Thaton)</div>

    <div class="user-area mobile-user">
      <span class="material-symbols-outlined">event_available</span>
    </div>

    <div class="user-area desktop-user">
      <span class="material-symbols-outlined">event_available</span>
    </div>
  </div>

  <nav class="sub-nav-links" id="navLinks">
    <a href="{{ asset('home') }}">Home</a>
    <span>•</span>
    <a href="#" class="active">King</a>
    <span>•</span>
    <a href="{{ asset('queen_selection') }}">Queen</a>
  </nav>
</header>

@php
    $loginCode = session('login_code');
    $currentUser = \App\Models\User::where('login_code', $loginCode)->first();
@endphp

<section class="ranking-section">
  <div class="ranking-container">
    @foreach ($kings as $king)
    <div class="contest-card">

      <!-- Slider -->
      <div class="slider">
        <a href="/king/{{ $king->sel_id }}">
          <img src="{{ asset('Images/1.jpg') }}" alt="Contestant" data-left="{{ $king->name }}" data-rank="{{ $king->number }}">
        </a>
        <a href="/king/{{ $king->sel_id }}">
          <img src="{{ asset('Images/2.jpg') }}" alt="Contestant" data-left="{{ $king->name }}" data-rank="{{ $king->number }}">
        </a>
        <a href="/king/{{ $king->sel_id }}">
          <img src="{{ asset('Images/3.jpg') }}" alt="Contestant" data-left="{{ $king->name }}" data-rank="{{ $king->number }}">
        </a>
        <div class="slider-dots"></div>
      </div>

      <!-- Card Body -->
      <div class="card-body">
        <div class="name-pair">
          <h3 id="leftName">{{ $king->name }}</h3>
          <div class="rank-badge rank-badge-floating" id="rankBadge">{{ $king->number }}</div>
        </div>

        <form method="POST" action="{{ route('vote.king', ['id' => $king->sel_id]) }}">
          @csrf
          <button type="submit" class="vote1"
              @if($currentUser && $currentUser->kflag == 0)
                  disabled
              @endif>
              Vote
          </button>
        </form>
      </div>
    </div>

    <div class="card-divider"></div>
    @endforeach
  </div>
</section>

<!-- Slider Script -->
<script>
document.querySelectorAll('.slider').forEach(slider => {
  const slides = slider.querySelectorAll('img');
  const dotsContainer = slider.querySelector('.slider-dots');
  const leftName = slider.closest('.contest-card').querySelector('#leftName');
  const rankBadge = slider.closest('.contest-card').querySelector('#rankBadge');

  let currentIndex = 0;
  let startX = 0;
  let currentX = 0;
  let isDragging = false;

  slides.forEach((_, i) => {
    const dot = document.createElement('span');
    if (i === 0) dot.classList.add('active');
    dot.addEventListener('click', () => {
      currentIndex = i;
      updateSlides();
      updateInfo();
    });
    dotsContainer.appendChild(dot);
  });

  const dots = dotsContainer.querySelectorAll('span');
  slides.forEach((img, i) => img.style.transform = `translateX(${i * 100}%)`);

  function updateSlides(offset = 0) {
    slides.forEach((img, i) => {
      img.style.transform = `translateX(${(i - currentIndex) * 100 + offset}%)`;
    });
    dots.forEach((dot, i) => dot.classList.toggle('active', i === currentIndex));
  }

  function updateInfo() {
    const active = slides[currentIndex];
    leftName.textContent = active.dataset.left;
    rankBadge.textContent = active.dataset.rank;
  }

  function startDrag(x) { startX = x; isDragging = true; }
  function onDrag(x) {
    if (!isDragging) return;
    currentX = x - startX;
    const percent = (currentX / slider.offsetWidth) * 100;
    updateSlides(percent);
  }
  function endDrag() {
    if (!isDragging) return;
    isDragging = false;
    const threshold = slider.offsetWidth * 0.25;
    if (currentX < -threshold && currentIndex < slides.length - 1) currentIndex++;
    else if (currentX > threshold && currentIndex > 0) currentIndex--;
    updateSlides();
    updateInfo();
    currentX = 0;
  }

  slider.addEventListener('mousedown', e => startDrag(e.clientX));
  window.addEventListener('mousemove', e => onDrag(e.clientX));
  window.addEventListener('mouseup', endDrag);

  slider.addEventListener('touchstart', e => startDrag(e.touches[0].clientX));
  slider.addEventListener('touchmove', e => onDrag(e.touches[0].clientX));
  slider.addEventListener('touchend', endDrag);

  updateInfo();
});

</script>

</body>
</html>
